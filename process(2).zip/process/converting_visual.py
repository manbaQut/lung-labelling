# -*- coding: utf-8 -*-
"""
File 1 Checker: 拓扑流向专项检验工具 (交互版)
功能：
1. [循环检验] 遍历 ./npy/ 目录，逐个弹出窗口。
2. [流向可视化] 
   - 起始点(Start) = 🟢 绿色小球
   - 终止点(End)   = 🔴 红色小球
   - 骨架线       = ⚫ 黑色线条
   * 正常逻辑：绿点应该在上游(靠近根)，红点在下游。
3. [断点检查] 如果看到红点和下一段绿点离得很远，说明拓扑断裂。
"""
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import os
import glob

# ================= ⚙️ 配置区域 =================
INPUT_FOLDER = "./npy/"  # 这里应该指向 File 1 输出的文件夹
# ==============================================

def force_full_view(ax, all_points):
    """自动调整 3D 视野范围，防止模型被压扁"""
    if not all_points: return
    points = np.vstack(all_points)
    min_vals = points.min(axis=0)
    max_vals = points.max(axis=0)
    center = (max_vals + min_vals) / 2
    max_range = (max_vals - min_vals).max()
    buffer = max_range * 0.55 
    
    ax.set_xlim(center[0]-buffer, center[0]+buffer)
    ax.set_ylim(center[1]-buffer, center[1]+buffer)
    ax.set_zlim(center[2]-buffer, center[2]+buffer)
    ax.set_box_aspect((1, 1, 1))
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

def visualize_one_file(filepath, current_idx, total_count):
    filename = os.path.basename(filepath)
    print(f"👉 [{current_idx}/{total_count}] 正在检验: {filename} ...")
    
    try:
        data = np.load(filepath, allow_pickle=True)
        if isinstance(data, np.ndarray): data = data.tolist()
    except Exception as e:
        print(f"   ❌ 读取失败: {e}")
        return

    # 创建交互式画布
    fig = plt.figure(figsize=(14, 10), dpi=120)
    ax = fig.add_subplot(111, projection='3d')
    ax.set_facecolor("white")
    
    all_points = []
    segment_count = 0
    
    for item in data:
        # 获取点集
        pts = item.get('member')
        # 如果 File 1 还没生成 member，尝试用 start/end 补救
        if pts is None or len(pts) == 0:
            p1 = item.get('start_point') or item.get('final_start')
            p2 = item.get('end_point') or item.get('final_end')
            if p1 is not None and p2 is not None:
                pts = np.array([p1, p2])
            else:
                continue
                
        pts = np.array(pts)
        if len(pts) < 2: continue
        
        all_points.append(pts)
        segment_count += 1
        
        # 1. 画骨架 (黑色半透明)
        ax.plot(pts[:,0], pts[:,1], pts[:,2], c='black', lw=1.2, alpha=0.6)
        
        # 2. 画流向标记
        # Start = 绿点 (Green) -> 应该在上游
        start_pt = pts[0]
        ax.scatter(start_pt[0], start_pt[1], start_pt[2], c='lime', s=8, alpha=0.9, depthshade=False)
        
        # End = 红点 (Red) -> 应该在下游
        end_pt = pts[-1]
        ax.scatter(end_pt[0], end_pt[1], end_pt[2], c='red', s=4, alpha=0.9, depthshade=False)

    force_full_view(ax, all_points)
    
    # 标题说明
    plt.title(f"File 1 Check: {filename}\nSegments: {segment_count}\n🟢Green=Start  --->  🔴Red=End", fontsize=14)
    
    # 提示信息
    print(f"   ✨ 窗口已弹出。请旋转检查流向是否为 [绿->红] 的层级下降。")
    print(f"   🚪 关闭窗口进入下一个...")
    
    plt.show() # 阻塞等待关闭
    plt.close(fig)

def main():
    if not os.path.exists(INPUT_FOLDER):
        print(f"❌ 目录不存在: {INPUT_FOLDER}")
        return

    files = glob.glob(os.path.join(INPUT_FOLDER, "*.npy"))
    if not files:
        print("❌ 未找到 NPY 文件。")
        return
    
    files.sort()
    total = len(files)
    
    print(f"🚀 启动 File 1 专项检验 (共 {total} 个文件)")
    print("="*60)
    
    for i, f in enumerate(files):
        visualize_one_file(f, i+1, total)
        print("-" * 60)
        
    print("✅ 检验结束。")

if __name__ == "__main__":
    main()