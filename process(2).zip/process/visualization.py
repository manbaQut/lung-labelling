# -*- coding: utf-8 -*-
"""
File 3 Loop: 3D 交互式循环检验工具
功能：
1. [循环遍历] 读取 ./output/ 下所有 NPY 文件。
2. [交互检查] 弹窗显示 3D 模型，支持鼠标旋转/缩放。
3. [流式操作] 关闭当前窗口后，自动弹出下一个文件的窗口。
"""
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.lines import Line2D
import os
import glob

# ================= ⚙️ 配置区域 =================
TARGET_FOLDER = "./output/"
# ==============================================

# --- 颜色定义 (保持您的修正版) ---
COLOR_TRACHEA = "#D3D3D3" 
COLOR_UNKNOWN = "#303030" 

COLORS = {
    "Trachea": COLOR_TRACHEA,
    
    # === 右肺 (Right Lung) - 暖色系 ===
    "RightMain": "#FF4500",           # 橙红色
    "RightUpperLobe": "#FFA500",      # 橙色
    "BronchusIntermedius": "#FFD700", # 金色
    
    # [修正保持]
    "RightMiddleLobe": "#FF00FF",     # 亮洋红
    "RightLowerLobe": "#8B0000",      # 深红色
    "RB1": "#E9967A",                 # 深肉色

    # === 左肺 (Left Lung) - 冷色系 ===
    "LeftMain": "#0000FF",            # 纯蓝
    "LeftUpperLobe": "#00FFFF",       # 青色
    "LeftLingular": "#32CD32",        # 酸橙绿
    "LeftLowerLobe": "#00008B",       # 深蓝色
    "LB1+2": "#4169E1"                # 皇家蓝
}

def pick_color(anat):
    if not anat or anat not in COLORS:
        return COLOR_UNKNOWN
    return COLORS[anat]

def force_full_view(ax, all_points):
    """自动调整 3D 视野范围"""
    if not all_points: return
    points = np.vstack(all_points)
    min_vals = points.min(axis=0)
    max_vals = points.max(axis=0)
    center = (max_vals + min_vals) / 2
    max_range = (max_vals - min_vals).max()
    buffer = max_range * 0.55 
    ax.set_xlim(center[0]-buffer, center[0]+buffer)
    ax.set_ylim(center[1]-buffer, center[1]+buffer)
    ax.set_zlim(center[2]-buffer, center[2]+buffer)
    ax.set_box_aspect((1, 1, 1))
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

def visualize_one_file(filepath, current_idx, total_count):
    """渲染单个文件的逻辑封装"""
    filename = os.path.basename(filepath)
    print(f"👉 [{current_idx}/{total_count}] 正在渲染: {filename} ... (关闭窗口以查看下一个)")
    
    try:
        data = np.load(filepath, allow_pickle=True)
        if isinstance(data, np.ndarray): data = data.tolist()
    except Exception as e:
        print(f"   ❌ 读取文件失败: {e}")
        return

    # 创建画布
    fig = plt.figure(figsize=(16, 12), dpi=120) # 稍微调小一点尺寸适应屏幕
    # 调整布局留出图例空间
    plt.subplots_adjust(left=0.05, right=0.75, top=0.95, bottom=0.05)
    
    ax = fig.add_subplot(111, projection='3d')
    ax.set_facecolor("white")

    all_points = []
    labeled_count = 0
    
    # 绘制气管
    for item in data:
        pts = item.get('member')
        if pts is None: continue
        pts = np.array(pts)
        if len(pts) < 2: continue
        all_points.append(pts)
        
        anat = item.get('anatomy')
        color = pick_color(anat)
        
        # 样式微调
        if anat == "Trachea":
            lw = 3.0
            labeled_count += 1
        elif anat is not None and anat in COLORS:
            lw = 2.0
            labeled_count += 1
        else:
            lw = 1.0 # 未知部分画细一点
            
        ax.plot(pts[:,0], pts[:,1], pts[:,2], c=color, lw=lw, alpha=0.9)

    force_full_view(ax, all_points)
    
    # --- 图例生成 ---
    legend_elements = []
    ordered_keys = [
        "Trachea", 
        "RightMain", "LeftMain",
        "RightUpperLobe", "LeftUpperLobe",
        "BronchusIntermedius",
        "RightMiddleLobe", "LeftLingular",
        "RightLowerLobe", "LeftLowerLobe"
    ]
    
    for key in ordered_keys:
        if key in COLORS:
            l_lw = 3.0 if key == "Trachea" else 2.0
            legend_elements.append(Line2D([0], [0], color=COLORS[key], lw=l_lw, label=key))

    for key, val in COLORS.items():
        if key not in ordered_keys and key != "Trachea":
             legend_elements.append(Line2D([0], [0], color=val, lw=2.0, label=key))

    ax.legend(handles=legend_elements, 
              loc='center left', 
              bbox_to_anchor=(1.05, 0.5), 
              fontsize='medium', 
              frameon=True,
              title="Anatomy Legend")
    
    # 标题显示文件名和进度
    plt.title(f"File: {filename}\nProgress: {current_idx}/{total_count} | Identified Segments: {labeled_count}", fontsize=14)
    
    print(f"   ✨ 窗口已弹出。请使用鼠标旋转/缩放模型。")
    print(f"   🚪 关闭该窗口后，将自动加载下一个文件...")
    
    # 阻塞式显示：程序会停在这里直到窗口关闭
    plt.show() 
    
    # 关闭后清理内存
    plt.close(fig)

def main():
    if not os.path.exists(TARGET_FOLDER):
        print(f"❌ 文件夹不存在: {TARGET_FOLDER}")
        return

    # 获取所有npy文件
    files = glob.glob(os.path.join(TARGET_FOLDER, "*.npy"))
    if not files:
        print(f"❌ 未找到任何 .npy 文件在: {TARGET_FOLDER}")
        return
    
    # 按文件名排序，保证顺序一致
    files.sort()
    
    total_files = len(files)
    print(f"🚀 准备就绪，共发现 {total_files} 个文件。开始逐个检验...")
    print("="*60)
    
    for i, f_path in enumerate(files):
        # i 从 0 开始，显示时加 1
        visualize_one_file(f_path, i+1, total_files)
        print("-" * 60)
        
    print("✅ 所有文件检验完毕！")

if __name__ == "__main__":
    main()