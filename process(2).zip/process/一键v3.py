# -*- coding: utf-8 -*-
"""
Pipeline Final V13: Spatial Quadrant Locking
核心修正 (BronchusIntermedius):
1. [禁飞区逻辑]: 
   - 以前只排序，现在先划定界限。
   - 任何 Z > 0.1 (明显朝上) 的分支，绝对不可能是中叶/下叶。强制归类为 RUL_Accessory。
2. [RLL锁定]:
   - 在向下的分支中，Z值最小(最陡峭)的锁定为 RLL。
3. [RML vs RB6]:
   - 剩下的向下分支中：
     - 指向后方 (Y < -0.2) -> RB6 (背段)。
     - 指向前方 (Y > -0.2) -> RML (中叶)。
"""

import json
import numpy as np
import os
import glob
from collections import deque
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.lines import Line2D

# ================= ⚙️ 路径配置 =================
INPUT_DIR = "./json/"
OUTPUT_NPY_DIR = "./output/"         
OUTPUT_IMG_DIR = "./output_images/"  

# ==============================================================================
# PART 1: Visualization V2 核心配置 (颜色字典)
# ==============================================================================

COLOR_TRACHEA = "#D3D3D3"
COLOR_UNKNOWN = "#202020"

COLORS = {
    "Trachea": COLOR_TRACHEA,
    "Trachea_Anomaly": "#FFFFFF",
    "RightMain": "#FF4500", "RightMain_Accessory": "#FF6347",
    "RightUpperLobe": "#FFA500", "RB1": "#FFD700", "RB2": "#CD853F", "RB3": "#FF8C00",
    "RB2+3": "#F4A460", "RUL_Accessory": "#FFE4B5",
    "BronchusIntermedius": "#DAA520",
    "RightMiddleLobe": "#FF00FF",     # 洋红 (中叶)
    "RightLowerLobe": "#8B0000",      # 深红 (下叶主干)
    "RB6": "#A52A2A",                 # 棕色 (下叶背段)
    "RightBasalTrunk": "#B22222",
    "LeftMain": "#0000FF", "LeftUpperLobe": "#00FFFF", "LB1+2": "#4169E1",
    "LB3": "#1E90FF", "LeftLingular": "#32CD32",
    "LeftLowerLobe": "#00008B", "LB6": "#8A2BE2", "LeftBasalTrunk": "#483D8B",
    "Spur": "#696969",
}

def pick_color(anat):
    if not anat: return COLOR_UNKNOWN
    if anat in COLORS: return COLORS[anat]
    if "_Sub" in anat or "_Accessory" in anat:
        base = anat.split("_")[0]
        if base in COLORS: return COLORS[base]
    return COLOR_UNKNOWN

def force_full_view(ax, all_points):
    if not all_points: return
    points = np.vstack(all_points)
    min_vals = points.min(axis=0)
    max_vals = points.max(axis=0)
    center = (max_vals + min_vals) / 2
    max_range = (max_vals - min_vals).max()
    buffer = max_range * 0.55 
    ax.set_xlim(center[0]-buffer, center[0]+buffer)
    ax.set_ylim(center[1]-buffer, center[1]+buffer)
    ax.set_zlim(center[2]-buffer, center[2]+buffer)
    ax.set_box_aspect((1, 1, 1))
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

# ==============================================================================
# PART 2: 数据处理 (Topology & Flow)
# ==============================================================================

def normalize(v):
    n = np.linalg.norm(v)
    return v / n if n > 1e-6 else np.array([0,0,1])

def process_topology_and_flow(json_path):
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            raw_data = json.load(f)
    except Exception as e:
        print(f"   ❌ JSON 读取失败: {e}")
        return []

    node_map = {}
    for item in raw_data:
        idx = str(item['index'])
        fid = str(item['fatherindex'])
        try:
            p1 = np.array(item.get('start', [0,0,0]), dtype=float)
            p2 = np.array(item.get('end', [0,0,0]), dtype=float)
            raw_member = item.get('member', [p1.tolist(), p2.tolist()])
            node_map[idx] = {
                "id": idx, "father_id": fid,
                "raw_endpoints": [p1, p2],
                "member": np.array(raw_member, dtype=float),
                "length": np.linalg.norm(p2 - p1),
                "children": [], "final_start": None, "final_end": None
            }
        except: continue

    potential_roots = []
    for idx, node in node_map.items():
        fid = node['father_id']
        if fid == "-1": potential_roots.append(idx)
        elif fid in node_map: node_map[fid]['children'].append(idx)
        else: potential_roots.append(idx)

    if not potential_roots: return []
    root_id = max(potential_roots, key=lambda rid: np.max(node_map[rid]['member'][:, 2]) if len(node_map[rid]['member'])>0 else -9999)

    root = node_map[root_id]
    rp1, rp2 = root['raw_endpoints']
    should_flip = False
    if root['children']:
        d1 = sum(min(np.linalg.norm(rp1-node_map[c]['raw_endpoints'][k]) for k in [0,1]) for c in root['children'])
        d2 = sum(min(np.linalg.norm(rp2-node_map[c]['raw_endpoints'][k]) for k in [0,1]) for c in root['children'])
        if d1 < d2: should_flip = True 
    elif rp1[2] < rp2[2]: should_flip = True 

    if should_flip:
        root['final_start'], root['final_end'] = rp2, rp1
        root['member'] = np.flip(root['member'], axis=0)
    else:
        root['final_start'], root['final_end'] = rp1, rp2

    global_offset = root['final_start'].copy()
    root['final_start'] -= global_offset; root['final_end'] -= global_offset; root['member'] -= global_offset
    
    queue = deque([root_id])
    processed = {root_id}
    final_list = []
    
    def fmt(n):
        return {
            "id": n['id'], "father_id": n['father_id'], 
            "start_point": n['final_start'], "end_point": n['final_end'], 
            "length": n['length'], "member": n['member'], "children": n['children']
        }

    final_list.append(fmt(root))

    while queue:
        pid = queue.popleft()
        p_end = node_map[pid]['final_end']
        for cid in node_map[pid]['children']:
            if cid in processed: continue
            c = node_map[cid]
            cp1 = c['raw_endpoints'][0] - global_offset
            cp2 = c['raw_endpoints'][1] - global_offset
            cmem = c['member'] - global_offset
            if np.linalg.norm(cp1 - p_end) < np.linalg.norm(cp2 - p_end):
                c['final_start'], c['final_end'], c['member'] = cp1, cp2, cmem
            else:
                c['final_start'], c['final_end'], c['member'] = cp2, cp1, np.flip(cmem, axis=0)
            final_list.append(fmt(c))
            processed.add(cid)
            queue.append(cid)

    roots = [n for n in final_list if n['father_id'] == "-1"]
    if roots and roots[0]['length'] < 10.0 and len(roots[0]['children']) == 1:
        old_root = roots[0]
        final_list = [n for n in final_list if n['id'] != old_root['id']]
        for n in final_list:
            if n['id'] == old_root['children'][0]: n['father_id'] = "-1"

    return final_list

# ==============================================================================
# PART 3: 算法内核 (V13: Quadrant Locking)
# ==============================================================================

def get_vec(node):
    return np.array(node['end_point']) - np.array(node['start_point'])

def get_angle(v1, v2):
    dot = np.dot(normalize(v1), normalize(v2))
    return np.degrees(np.arccos(np.clip(dot, -1.0, 1.0)))

class AnatomyNavigator:
    def __init__(self, data):
        self.node_map = {str(d['id']): d for d in data}
        self.results = {} 
        self.subtree_weights = {} 
        self.children_map = {}
        for d in data:
            fid = str(d['father_id'])
            if fid not in self.children_map: self.children_map[fid] = []
            self.children_map[fid].append(str(d['id']))
        self._calc_subtree_weights()

    def _calc_subtree_weights(self):
        for nid in self.node_map:
            if nid not in self.subtree_weights: self._get_weight_recursive(nid)

    def _get_weight_recursive(self, nid):
        if nid in self.subtree_weights: return self.subtree_weights[nid]
        w = self.node_map[nid]['length']
        for cid in self.children_map.get(nid, []): w += self._get_weight_recursive(cid)
        self.subtree_weights[nid] = w
        return w

    def solve(self):
        root = next((nid for nid, n in self.node_map.items() if str(n['father_id']) == "-1"), None)
        if root: self._solve_recursive_path(root, "Trachea")
        return self.results

    def _trace_linear_path(self, start_id):
        curr = start_id
        path = []
        while True:
            path.append(curr)
            kids = [self.node_map[k] for k in self.children_map.get(curr, []) if k in self.node_map]
            if not kids: return path, self.node_map[curr], []
            
            kids.sort(key=lambda x: self.subtree_weights[str(x['id'])], reverse=True)
            if len(kids) == 1:
                curr = str(kids[0]['id']); continue
            
            w0 = self.subtree_weights[str(kids[0]['id'])]
            w1 = self.subtree_weights[str(kids[1]['id'])]
            if (w1 / w0) < 0.15:
                for k in kids[1:]: self.results[k['id']] = "Spur"
                curr = str(kids[0]['id'])
            else:
                valid = [k for k in kids if (self.subtree_weights[str(k['id'])] / w0) > 0.10]
                return path, self.node_map[curr], valid

    def _solve_recursive_path(self, start_id, label):
        pids, junction, kids = self._trace_linear_path(start_id)
        for pid in pids: self.results[pid] = label
        if not kids: return

        # === 核心逻辑 ===
        if label == "Trachea":
            kids.sort(key=lambda k: (k['start_point'][0] + k['end_point'][0])/2)
            if len(kids) >= 2:
                self._solve_recursive_path(kids[0]['id'], "RightMain")
                self._solve_recursive_path(kids[-1]['id'], "LeftMain")
                for k in kids[1:-1]: self._solve_recursive_path(k['id'], "Trachea_Anomaly")

        elif label == "RightMain":
            v_p = get_vec(junction)
            angs = sorted([(k, get_angle(get_vec(k), v_p)) for k in kids], key=lambda x: x[1], reverse=True)
            self._solve_recursive_path(angs[0][0]['id'], "RightUpperLobe")
            self._solve_recursive_path(angs[-1][0]['id'], "BronchusIntermedius")
            for k in [x[0] for x in angs[1:-1]]: self._solve_recursive_path(k['id'], "RightMain_Accessory")

        elif label == "LeftMain":
            kids.sort(key=lambda k: k['end_point'][2])
            self._solve_recursive_path(kids[0]['id'], "LeftLowerLobe")
            for k in kids[1:]: self._solve_recursive_path(k['id'], "LeftUpperLobe")

        # =================================================================
        # 🔥 V13 核心修正: 空间象限锁定 (Quadrant Locking) 🔥
        # =================================================================
        elif label == "BronchusIntermedius":
            candidates = []
            for k in kids:
                vec = normalize(get_vec(k))
                candidates.append((k, vec))
            
            # 按 Z 轴排序 (从下到上)
            candidates.sort(key=lambda x: x[1][2])
            
            # 1. 寻找主路 (RightLowerLobe)
            # 必须是向下的 (Z < 0) 且 Z 最小的那根
            rll_found = False
            
            remaining = []
            
            # 先取 Z 最小的作为 RLL 候选
            if candidates[0][1][2] < 0:
                rll_node = candidates[0][0]
                self._solve_recursive_path(rll_node['id'], "RightLowerLobe")
                rll_found = True
                remaining = candidates[1:]
            else:
                # 如果连最小的都是朝上的，那说明这段 BI 可能本身就反了，或者全是异常
                # 这种情况下强行指派最下面的为 RLL
                rll_node = candidates[0][0]
                self._solve_recursive_path(rll_node['id'], "RightLowerLobe")
                remaining = candidates[1:]

            # 2. 处理剩余分支
            for item in remaining:
                node = item[0]
                vec = item[1]
                z_val = vec[2]
                y_val = vec[1]
                
                # [禁飞区判断]
                # 如果 Z > 0.1 (明显朝上)，这绝对不是中叶/下叶
                # 这可能是上叶没切干净的尾巴
                if z_val > 0.1:
                    self._solve_recursive_path(node['id'], "RUL_Accessory") # 归为上叶副支(橙色系)
                
                # [对立面判断]
                # Y < -0.2 (明显向后) -> RB6
                elif y_val < -0.2:
                    self._solve_recursive_path(node['id'], "RB6")
                
                # [中叶归属]
                # 向下(Z<0.1) 且 向前/侧 (Y>-0.2)
                else:
                    self._solve_recursive_path(node['id'], "RightMiddleLobe")

        # =================================================================

        # --- Level 4 ---
        elif label == "RightUpperLobe":
            pool = sorted(kids, key=lambda k: get_vec(k)[2], reverse=True)
            if pool and get_vec(pool[0])[2] > 0: self._solve_recursive_path(pool.pop(0)['id'], "RB1")
            if len(pool) >= 2:
                pool.sort(key=lambda k: get_vec(k)[1])
                self._solve_recursive_path(pool.pop(0)['id'], "RB2") 
                self._solve_recursive_path(pool.pop(-1)['id'], "RB3") 
            elif pool: self._solve_recursive_path(pool[0]['id'], "RB2+3")
        
        elif label == "LeftUpperLobe":
            pool = sorted(kids, key=lambda k: k['end_point'][2])
            self._solve_recursive_path(pool.pop(0)['id'], "LeftLingular")
            for k in pool: self._solve_recursive_path(k['id'], "LB1+2" if get_vec(k)[2] > 0 else "LB3")
        
        elif label in ["LeftLowerLobe", "RightLowerLobe"]:
            suffix = "Left" if "Left" in label else "Right"
            v_p = get_vec(junction)
            angs = sorted([(k, get_angle(get_vec(k), v_p)) for k in kids], key=lambda x: x[1], reverse=True)
            
            if label == "RightLowerLobe":
                back_candidates = [x for x in angs if normalize(get_vec(x[0]))[1] < -0.2]
                if back_candidates:
                    rb6 = back_candidates[0][0]
                    self._solve_recursive_path(rb6['id'], "RB6")
                    angs.remove(back_candidates[0])
            
            if label == "LeftLowerLobe":
                 back_candidates = [x for x in angs if normalize(get_vec(x[0]))[1] < -0.2]
                 if back_candidates:
                     lb6 = back_candidates[0][0]
                     self._solve_recursive_path(lb6['id'], "LB6")
                     angs.remove(back_candidates[0])

            for x in angs:
                self._solve_recursive_path(x[0]['id'], f"{suffix}BasalTrunk")
        
        else:
            for i, k in enumerate(kids): self._solve_recursive_path(k['id'], f"{label}_Sub{i+1}")

# ==============================================================================
# PART 4: 渲染执行
# ==============================================================================

def render_visualization_v2_style(node_data, filename):
    fig = plt.figure(figsize=(16, 12), dpi=120) 
    plt.subplots_adjust(left=0.05, right=0.75, top=0.95, bottom=0.05)
    ax = fig.add_subplot(111, projection='3d')
    ax.set_facecolor("white")

    all_points = []
    labeled_count = 0
    present_labels = set()
    
    for item in node_data:
        pts = item.get('member')
        if pts is None or len(pts) < 2: continue
        all_points.append(pts)
        anat = item.get('anatomy')
        if anat: present_labels.add(anat)
        color = pick_color(anat)
        
        if anat and anat in COLORS:
            lw = 2.0; alpha = 0.9
            labeled_count += 1
        elif anat == "Spur":
            lw = 0.5; alpha = 0.3
        else:
            lw = 0.8; alpha = 0.2
        ax.plot(pts[:,0], pts[:,1], pts[:,2], c=color, lw=lw, alpha=alpha)

    force_full_view(ax, all_points)
    
    legend_elements = []
    priority_order = [
        "Trachea", 
        "RightMain", "RightUpperLobe", "RB1", "RB2", "RB3", 
        "BronchusIntermedius", "RightMiddleLobe", 
        "RightLowerLobe", "RB6", "RightBasalTrunk",
        "LeftMain", "LeftUpperLobe", "LB1+2", "LeftLingular",
        "LeftLowerLobe", "LB6", "LeftBasalTrunk"
    ]
    
    for key in priority_order:
        if key in present_labels:
            legend_elements.append(Line2D([0], [0], color=COLORS[key], lw=3, label=key))
            present_labels.remove(key)
    for key in present_labels:
        if key in COLORS:
             legend_elements.append(Line2D([0], [0], color=COLORS[key], lw=2, label=key))

    ax.legend(handles=legend_elements, loc='center left', bbox_to_anchor=(1.0, 0.5), fontsize='small', frameon=True, title=f"Detected Anatomy\n(Total: {labeled_count})")
    plt.title(f"File: {filename}\n[Pipeline V13] Spatial Quadrant Locking (No High RML)", fontsize=14)
    
    if not os.path.exists(OUTPUT_IMG_DIR): os.makedirs(OUTPUT_IMG_DIR)
    img_path = os.path.join(OUTPUT_IMG_DIR, filename.replace(".json", ".png"))
    plt.savefig(img_path)
    print(f"   📸 截图已保存: {img_path}")
    print(f"   👀 [V13 Window] 请检查三维窗口 (关闭后继续)...")
    plt.show() 
    plt.close(fig)

# ================= 🚀 主程序入口 =================

def main():
    if not os.path.exists(INPUT_DIR):
        print(f"❌ 找不到输入目录: {INPUT_DIR}")
        return
    if not os.path.exists(OUTPUT_NPY_DIR): os.makedirs(OUTPUT_NPY_DIR)
    
    files = glob.glob(os.path.join(INPUT_DIR, "*.json"))
    files.sort()
    print(f"🚀 启动 V13 (象限锁定逻辑): 处理 {len(files)} 个文件...")

    for i, f_path in enumerate(files):
        fname = os.path.basename(f_path)
        print(f"\n👉 [{i+1}/{len(files)}] 正在处理: {fname}")
        
        nodes = process_topology_and_flow(f_path)
        if not nodes: continue
            
        try:
            nav = AnatomyNavigator(nodes)
            labels = nav.solve()
        except Exception as e:
            print(f"   ❌ 算法错误: {e}")
            labels = {}
            
        final_data = []
        for node in nodes:
            node['anatomy'] = labels.get(str(node['id']), None)
            final_data.append(node)
            
        npy_path = os.path.join(OUTPUT_NPY_DIR, fname.replace(".json", ".npy"))
        np.save(npy_path, final_data)
        
        render_visualization_v2_style(final_data, fname)

    print("\n✨ 全部流程结束！")

if __name__ == "__main__":
    main()