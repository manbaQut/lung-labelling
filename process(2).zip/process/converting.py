# -*- coding: utf-8 -*-
"""
File 1 Corrected: 拓扑重建 + 智能流向重塑 + 坐标归零
修复重点：
1. [Root锁定] 不再盲信 Index 0，而是寻找 fatherindex == -1 的拓扑根。
2. [全量翻转] 当发现气管方向反了时，不仅交换起止点，同时翻转 member 点序。
3. [流向传递] 基于父节点末端位置，递归校正所有子节点的流向。
"""
import json
import numpy as np
import os
import glob
from collections import deque

INPUT_DIR = "./json/"
OUTPUT_DIR = "./npy/"

def normalize(v):
    n = np.linalg.norm(v)
    return v / n if n > 1e-6 else np.array([0,0,1]) # 防止除零

def process_single_file(json_path):
    print(f"👉 正在处理: {os.path.basename(json_path)}")
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            raw_data = json.load(f)
    except Exception as e:
        print(f"   ❌ JSON 读取失败: {e}")
        return []

    # -------------------------------------------------
    # 1. 数据清洗与初步构建
    # -------------------------------------------------
    node_map = {}
    
    # 第一遍扫描：加载所有节点
    for item in raw_data:
        # 强制转字符串，防止 int/str 混用导致匹配失败
        idx = str(item['index'])
        fid = str(item['fatherindex'])
        
        try:
            p1 = np.array(item.get('start', [0,0,0]), dtype=float)
            p2 = np.array(item.get('end', [0,0,0]), dtype=float)
            # 确保 member 是 numpy 数组
            raw_member = item.get('member', [p1.tolist(), p2.tolist()])
            member = np.array(raw_member, dtype=float)
            length = np.linalg.norm(p2 - p1)
        except Exception as e:
            print(f"   ⚠️ 节点 {idx} 数据异常，跳过: {e}")
            continue
        
        node_map[idx] = {
            "id": idx, 
            "father_id": fid,
            "raw_endpoints": [p1, p2], # 原始端点，尚未定序
            "member": member, 
            "length": length,
            "children": [],            # 待填充
            "final_start": None,       # 待计算
            "final_end": None,         # 待计算
            "is_inverted": False       # 记录是否发生了翻转
        }

    # -------------------------------------------------
    # 2. 拓扑连接 (建立父子关系)
    # -------------------------------------------------
    potential_roots = []
    
    for idx, node in node_map.items():
        fid = node['father_id']
        
        # 判定是否为根候选：没有父节点 或 父节点ID为 -1
        if fid == "-1":
            potential_roots.append(idx)
        elif fid in node_map:
            node_map[fid]['children'].append(idx)
        else:
            # 有 father_id 但在 map 里找不到父节点，说明是悬空节点或根
            # 这种情况也暂且视为根候选
            potential_roots.append(idx)

    # -------------------------------------------------
    # 3. 智能锁定 Root (Trachea)
    # -------------------------------------------------
    root_id = None
    
    if len(potential_roots) == 0:
        print("   ❌ 错误: 未找到任何根节点 (无 fatherindex=-1)")
        return []
    elif len(potential_roots) == 1:
        root_id = potential_roots[0]
        print(f"   ✅ 锁定唯一拓扑根: ID {root_id}")
    else:
        # 如果有多个候选根，选择 Z 轴最高的那个 (医学上气管在上方)
        # 或者选择最长的那个
        print(f"   ⚠️ 发现多个断开的根: {potential_roots}，尝试择优...")
        best_z = -float('inf')
        for rid in potential_roots:
            pts = node_map[rid]['member']
            if len(pts) > 0:
                max_z = np.max(pts[:, 2])
                if max_z > best_z:
                    best_z = max_z
                    root_id = rid
        print(f"   ✅ 选定最高点作为主根: ID {root_id} (Z={best_z:.1f})")

    # -------------------------------------------------
    # 4. 根节点流向初始化
    # -------------------------------------------------
    root = node_map[root_id]
    rp1, rp2 = root['raw_endpoints']
    
    # 判断根的方向：
    # 规则A: 如果有孩子，Root.End 应该离所有孩子的 Start 总距离最近
    # 规则B: 如果没孩子(孤立)，医学上气管是 Z 轴向下的 (Start.z > End.z)
    
    should_flip_root = False
    
    if root['children']:
        # 收集所有孩子的所有端点，看哪一组离 rp1 近，哪一组离 rp2 近
        d1_sum, d2_sum = 0, 0
        for cid in root['children']:
            c = node_map[cid]
            cp1, cp2 = c['raw_endpoints']
            # 计算 rp1 到该孩子任意端点的最短距
            d1_sum += min(np.linalg.norm(rp1 - cp1), np.linalg.norm(rp1 - cp2))
            d2_sum += min(np.linalg.norm(rp2 - cp1), np.linalg.norm(rp2 - cp2))
            
        if d1_sum < d2_sum: 
            # rp1 离孩子们更近，说明 rp1 是 End，rp2 是 Start
            should_flip_root = True
    else:
        # 没孩子，按 Z 轴判断：气管应该向下生长，Start.z > End.z
        if rp1[2] < rp2[2]: # 如果 p1 在下方，p2 在上方
             should_flip_root = True # 让 p2(上) 做 Start

    if should_flip_root:
        root['final_start'], root['final_end'] = rp2, rp1
        root['member'] = np.flip(root['member'], axis=0) # 关键：翻转 member 顺序！
        root['is_inverted'] = True
    else:
        root['final_start'], root['final_end'] = rp1, rp2

    # -------------------------------------------------
    # 5. BFS 递归传递流向 + 坐标归零
    # -------------------------------------------------
    # 以根节点的 Start 为原点
    global_offset = root['final_start'].copy()
    print(f"   📍 坐标原点修正: {global_offset}")

    # 先处理根节点的归零
    root['final_start'] -= global_offset
    root['final_end'] -= global_offset
    root['member'] -= global_offset

    queue = deque([root_id])
    processed = {root_id}
    final_list = []
    
    # 先加入根节点
    final_list.append(format_node(root))

    while queue:
        pid = queue.popleft() # BFS
        parent = node_map[pid]
        p_end_corrected = parent['final_end'] # 这是已经归零且方向正确的父节点末端
        
        for cid in parent['children']:
            if cid in processed: continue
            child = node_map[cid]
            
            # 原始坐标归零 (暂不确定方向)
            cp1 = child['raw_endpoints'][0] - global_offset
            cp2 = child['raw_endpoints'][1] - global_offset
            child_mem = child['member'] - global_offset
            
            # 距离判断：哪个端点离父节点末端更近？
            d1 = np.linalg.norm(cp1 - p_end_corrected)
            d2 = np.linalg.norm(cp2 - p_end_corrected)
            
            if d1 < d2:
                # cp1 是头，cp2 是尾 (正常)
                child['final_start'] = cp1
                child['final_end'] = cp2
                child['member'] = child_mem # 顺序不变
            else:
                # cp2 是头，cp1 是尾 (反了)
                child['final_start'] = cp2
                child['final_end'] = cp1
                child['member'] = np.flip(child_mem, axis=0) # 关键：翻转 member
                child['is_inverted'] = True
            
            final_list.append(format_node(child))
            processed.add(cid)
            queue.append(cid)

    # 检查是否有孤立节点未被处理 (断链)
    if len(final_list) < len(node_map):
        print(f"   ⚠️ 警告: 输入 {len(node_map)} 个节点，输出 {len(final_list)} 个。")
        print("   可能存在断开的孤岛节点，已自动舍弃。")

    # ... (在 BFS 循环结束后，return 之前) ...

    # === 新增：清理微小根节点 (Root Pruning) ===
    # 如果 Root 非常短 (< 5mm) 且只有一个孩子，说明它是扫描造成的噪点
    # 我们应该“晋升”它的孩子为新 Root
    
    # 找到当前的 Root 节点 (没有父节点的节点)
    current_roots = [n for n in final_list if n['father_id'] == "-1" or n['father_id'] not in [x['id'] for x in final_list]]
    
    if current_roots:
        root_node = current_roots[0]
        # 条件：长度小于 10mm 且 只有一个孩子
        if root_node['length'] < 10.0 and len(root_node['children']) == 1:
            print(f"   ✂️ 剪枝: 移除微小根节点 {root_node['id']} (Len={root_node['length']:.1f})，晋升子节点。")
            
            child_id = root_node['children'][0]
            # 从列表中移除旧 Root
            final_list = [n for n in final_list if n['id'] != root_node['id']]
            
            # 更新孩子的 father_id 为 -1 (成为新皇)
            for n in final_list:
                if n['id'] == child_id:
                    n['father_id'] = "-1"
                    # 修正坐标（因为之前的归零是基于旧Root的，这里可以不做，因为相对位置没错，只要标记对就行）
                    break

    return final_list

def format_node(node):
    # 计算最终向量
    vec = node['final_end'] - node['final_start']
    return {
        "id": node['id'], 
        "father_id": node['father_id'],
        "start_point": node['final_start'], 
        "end_point": node['final_end'],
        "direction": normalize(vec), 
        "length": node['length'],
        "member": node['member'], 
        "children": node['children']
    }

def main():
    if not os.path.exists(OUTPUT_DIR): os.makedirs(OUTPUT_DIR)
    # 支持 json/*.json
    files = glob.glob(os.path.join(INPUT_DIR, "*.json"))
    
    if not files:
        print(f"❌ 在 {INPUT_DIR} 目录下没有找到 .json 文件！")
        return

    print("🚀 开始数据转换与流向修正...")
    for f in files:
        data = process_single_file(f)
        if data:
            out_name = os.path.basename(f).replace(".json", ".npy")
            np.save(os.path.join(OUTPUT_DIR, out_name), data)
            print(f"   💾 已保存: {out_name}")
    print("✨ 全部完成。")

if __name__ == "__main__":
    main()