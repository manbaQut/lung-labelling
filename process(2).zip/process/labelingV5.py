# -*- coding: utf-8 -*-
"""
File 2 V5: 终极全覆盖版 (N叉树适配 + 向量竞价匹配)
核心改进：
1. [N叉树支持] 彻底放弃 k1,k2 的二元限制，支持任意数量的子分支(三分叉/四分叉)。
2. [向量竞价] 针对 RUL/LLL 等部位，定义期望向量(如向上/向后)，让子分支竞争匹配。
3. [全员上岗] 匹配完标准段后，剩余的"多余分支"会自动获得 Accessory 标签，绝不留黑。
"""
import numpy as np
import os
import glob
from collections import deque

INPUT_DIR = "./npy/"
OUTPUT_DIR = "./output/"

# ================= 🔧 向量工具箱 =================
def normalize(v):
    n = np.linalg.norm(v)
    return v / n if n > 1e-6 else np.array([0,0,1])

def get_angle(v1, v2):
    """计算夹角 (0-180度)"""
    dot = np.dot(normalize(v1), normalize(v2))
    return np.degrees(np.arccos(np.clip(dot, -1.0, 1.0)))

def get_vec(node):
    """获取节点向量 (Start -> End)"""
    p1 = np.array(node['start_point'])
    p2 = np.array(node['end_point'])
    return p2 - p1

def get_projection_z(node):
    """获取 Z 轴投影长度 (向上为正)"""
    v = get_vec(node)
    return v[2]

# ================= 🧠 核心算法类 =================
class AnatomyNavigator:
    def __init__(self, data):
        self.node_map = {str(d['id']): d for d in data}
        self.results = {} 
        self.subtree_weights = {} 
        self.children_map = {}
        for d in data:
            fid = str(d['father_id'])
            if fid not in self.children_map: self.children_map[fid] = []
            self.children_map[fid].append(str(d['id']))
        self._calc_subtree_weights()

    def _calc_subtree_weights(self):
        for nid in self.node_map:
            if nid not in self.subtree_weights:
                self._get_weight_recursive(nid)

    def _get_weight_recursive(self, nid):
        if nid in self.subtree_weights: return self.subtree_weights[nid]
        node = self.node_map[nid]
        w = node['length']
        for cid in self.children_map.get(nid, []):
            w += self._get_weight_recursive(cid)
        self.subtree_weights[nid] = w
        return w

    def solve(self):
        print("   🧠 启动 N叉树全覆盖标记...")
        root_id = self._find_robust_root()
        if not root_id: return {}
        self._solve_recursive_path(root_id, "Trachea")
        return self.results

    def _find_robust_root(self):
        candidates = []
        for nid, node in self.node_map.items():
            fid = str(node['father_id'])
            if fid == "-1" or fid not in self.node_map:
                z_max = max(node['start_point'][2], node['end_point'][2])
                candidates.append((nid, z_max))
        if not candidates: return None
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][0]

    def _trace_linear_path(self, start_id):
        """穿透追踪：返回路径和【所有】有效孩子"""
        curr_id = start_id
        path_nodes = []
        while True:
            path_nodes.append(curr_id)
            kids_ids = self.children_map.get(curr_id, [])
            kids = [self.node_map[k] for k in kids_ids]
            
            if not kids: return path_nodes, self.node_map[curr_id], []
            
            # 按权重排序
            kids.sort(key=lambda x: self.subtree_weights[str(x['id'])], reverse=True)
            
            # 单行道 -> 穿透
            if len(kids) == 1:
                curr_id = str(kids[0]['id'])
                continue
            
            # 统治度校验 (防止噪点)
            w_big = self.subtree_weights[str(kids[0]['id'])]
            w_second = self.subtree_weights[str(kids[1]['id'])]
            ratio = w_second / w_big if w_big > 0 else 0
            
            # 如果老二太弱，说明是假分叉
            if ratio < 0.15: 
                # 标记其他所有弱小的为 Spur
                for k in kids[1:]: self.results[k['id']] = "Spur"
                # 继续沿老大穿透
                curr_id = str(kids[0]['id'])
                continue
            else:
                # 真分叉：返回所有过了阈值的孩子 (可能 > 2 个)
                valid_kids = []
                for k in kids:
                    # 再次过滤一下过小的
                    if self.subtree_weights[str(k['id'])] / w_big > 0.10:
                        valid_kids.append(k)
                    else:
                        self.results[k['id']] = "Spur"
                return path_nodes, self.node_map[curr_id], valid_kids

    def _solve_recursive_path(self, start_id, label):
        path_ids, junction_node, children = self._trace_linear_path(start_id)
        for pid in path_ids: self.results[pid] = label
            
        if not children: return

        # === 核心：N叉树匹配逻辑 ===
        # 我们定义一个 helper 来处理 children 的分配
        
        # 1. Trachea -> RMB / LMB
        if label == "Trachea":
            # 简单的左右分类：中心点 X 坐标
            # 假设 X 小是右(R)，X 大是左(L)
            rights = []
            lefts = []
            for k in children:
                cx = (k['start_point'][0] + k['end_point'][0])/2
                # 这里最好跟 Junction 比较，或者相互比较
                # 简单法：按 X 排序，小的一半是右，大的一半是左
                pass # 暂且保留原来的二分逻辑作为基础，N叉主要用于 Level 3/4
            
            # 对于主分叉，通常是二分的。如果是三分叉，可能是气管支气管(Tracheal Bronchus)变异
            # 我们可以简单按 X 坐标排序
            children.sort(key=lambda k: (k['start_point'][0] + k['end_point'][0])/2)
            
            # 最右边的(X最小)是 RMB，最左边的是 LMB
            # 如果中间还有，标记为 Trachea_Accessory
            if len(children) >= 2:
                rmb = children[0]
                lmb = children[-1]
                self._solve_recursive_path(rmb['id'], "RightMain")
                self._solve_recursive_path(lmb['id'], "LeftMain")
                
                for k in children[1:-1]:
                    self._solve_recursive_path(k['id'], "Trachea_Anomaly")

        # 2. RightMain -> RUL / BI
        elif label == "RightMain":
            # 向量竞价：
            # RUL: 向量通常向侧上方 (Z大, X小)
            # BI: 向量通常向下 (Z小)
            # 策略：找跟父向量夹角最大的(岔出去的)是 RUL
            v_parent = get_vec(junction_node)
            
            # 计算每个孩子与父向量的夹角
            angles = [(k, get_angle(get_vec(k), v_parent)) for k in children]
            angles.sort(key=lambda x: x[1], reverse=True) # 夹角大的在前
            
            # 夹角最大的定为 RUL
            rul = angles[0][0]
            self._solve_recursive_path(rul['id'], "RightUpperLobe")
            
            # 剩下的都是 BI (中间段)
            # 正常BI只有一个，如果有多的，也算进BI或BI_Acc
            rest = [x[0] for x in angles[1:]]
            # 夹角最小的(最顺的)是主BI
            bi = rest[-1] # 刚才排序是降序，所以最后一个夹角最小
            self._solve_recursive_path(bi['id'], "BronchusIntermedius")
            
            # 处理中间多余的
            for k in rest[:-1]:
                self._solve_recursive_path(k['id'], "RightMain_Accessory")

        # 3. LeftMain -> LUL / LLL
        elif label == "LeftMain":
            # 判据：Z 轴。LLL 去最下面。
            children.sort(key=lambda k: k['end_point'][2]) # 升序，Z小的在前面(下)
            
            lll = children[0] # 最下面的
            self._solve_recursive_path(lll['id'], "LeftLowerLobe")
            
            # 剩下的通常是 LUL
            # 如果有多个，可能 LUL 提前分叉了，或者有副叶
            for k in children[1:]:
                self._solve_recursive_path(k['id'], "LeftUpperLobe")

        # 4. BronchusIntermedius -> RML / RLL
        elif label == "BronchusIntermedius":
            # RLL 向下(Z小)，RML 向前(Y大/X小)
            # 简单判据：跟父向量夹角小的(顺流)是 RLL
            v_parent = get_vec(junction_node)
            angles = [(k, get_angle(get_vec(k), v_parent)) for k in children]
            angles.sort(key=lambda x: x[1]) # 升序，夹角小的在前
            
            rll = angles[0][0] # 最顺的
            self._solve_recursive_path(rll['id'], "RightLowerLobe")
            
            for k in [x[0] for x in angles[1:]]:
                self._solve_recursive_path(k['id'], "RightMiddleLobe")

        # === Level 4: 肺段级 N 叉匹配 ===
        
        # 5. RightUpperLobe -> RB1 / RB2 / RB3
        elif label == "RightUpperLobe":
            # 定义槽位和特征
            # RB1 (Apical): Z轴向上分量最大
            # RB2 (Posterior): Y轴向后 (假设Y小是后) 或 Z轴略微向下
            # RB3 (Anterior): Y轴向前 (假设Y大是前)
            
            # 这里的匹配需要坐标系知识，假设 Z上, Y前, X左
            
            # 1. 先把所有孩子列出来
            pool = children[:]
            
            # 2. 竞标 RB1 (尖段) - 找 Z 最大的
            pool.sort(key=lambda k: get_vec(k)[2], reverse=True)
            if pool and get_vec(pool[0])[2] > 0: # 必须有点向上
                rb1 = pool.pop(0)
                self._solve_recursive_path(rb1['id'], "RB1")
            
            # 3. 剩下的里面分 RB2 和 RB3
            # 如果还有2个以上，按 Y 轴分：Y 大的前段(RB3)，Y 小的后段(RB2)
            if len(pool) >= 2:
                pool.sort(key=lambda k: get_vec(k)[1]) # Y 升序 (后 -> 前)
                rb2 = pool.pop(0) # 最小的Y (后)
                rb3 = pool.pop(-1) # 最大的Y (前)
                self._solve_recursive_path(rb2['id'], "RB2")
                self._solve_recursive_path(rb3['id'], "RB3")
            elif len(pool) == 1:
                # 只剩一个了，笼统标记为 RB2+3
                self._solve_recursive_path(pool[0]['id'], "RB2+3")
            
            # 4. 如果还有多出来的 (Trifurcation 之外的第四根)
            for k in pool:
                self._solve_recursive_path(k['id'], "RUL_Accessory")

        # 6. LeftUpperLobe -> LB1+2 / LB3 / Lingula
        elif label == "LeftUpperLobe":
            # Lingula (舌叶): 明显向下走 (Z 最小)
            pool = children[:]
            pool.sort(key=lambda k: k['end_point'][2]) # Z 升序
            
            lingula = pool.pop(0) # 最下面的
            self._solve_recursive_path(lingula['id'], "LeftLingular")
            
            # 剩下的归为固有上叶 (Upper Division)
            # 可以细分 LB1+2 (尖后) 和 LB3 (前)
            # LB1+2 通常向上
            for k in pool:
                v = get_vec(k)
                if v[2] > 0: # 向上
                    self._solve_recursive_path(k['id'], "LB1+2")
                else:
                    self._solve_recursive_path(k['id'], "LB3")

        # 7. LeftLowerLobe -> LB6 / Basal
        elif label == "LeftLowerLobe":
            # LB6 (背段): 向后 (Y 小) 且 Z 轴下降不明显
            # Basal (基底): 向下 (Z 小)
            
            # 简单策略：夹角大的(岔出去的)是背段
            v_parent = get_vec(junction_node)
            angles = [(k, get_angle(get_vec(k), v_parent)) for k in children]
            angles.sort(key=lambda x: x[1], reverse=True) # 降序，岔得最开的在前
            
            lb6 = angles[0][0]
            self._solve_recursive_path(lb6['id'], "LB6")
            
            # 剩下的都是基底干
            for k in [x[0] for x in angles[1:]]:
                self._solve_recursive_path(k['id'], "LeftBasalTrunk")

        # 8. RightLowerLobe -> RB6 / Basal
        elif label == "RightLowerLobe":
            # 同左下叶
            v_parent = get_vec(junction_node)
            angles = [(k, get_angle(get_vec(k), v_parent)) for k in children]
            angles.sort(key=lambda x: x[1], reverse=True)
            
            rb6 = angles[0][0]
            self._solve_recursive_path(rb6['id'], "RB6")
            
            for k in [x[0] for x in angles[1:]]:
                self._solve_recursive_path(k['id'], "RightBasalTrunk")
        
        # 9. 其他通用情况 (LB6 分支, RB1 分支等)
        else:
            # 对于更深层级，我们可能没有具体名字，但不能让它们黑着
            # 统一赋予 "Parent_Sub" 标签
            for i, k in enumerate(children):
                sub_label = f"{label}_Sub{i+1}"
                self._solve_recursive_path(k['id'], sub_label)

def main():
    if not os.path.exists(INPUT_DIR): return
    if not os.path.exists(OUTPUT_DIR): os.makedirs(OUTPUT_DIR)
    
    files = glob.glob(os.path.join(INPUT_DIR, "*.npy"))
    print(f"🚀 V5 处理开始 (N叉树全覆盖模式)...")
    
    for f in files:
        try:
            raw = np.load(f, allow_pickle=True)
            data = raw.tolist() if isinstance(raw, np.ndarray) else raw
            nav = AnatomyNavigator(data)
            res = nav.solve()
            
            out = []
            for item in data:
                out.append({
                    "id": item['id'],
                    "member": item.get('member', []),
                    "start_point": item.get('start_point'),
                    "end_point": item.get('end_point'),
                    "anatomy": res.get(str(item['id']), None)
                })
            np.save(os.path.join(OUTPUT_DIR, os.path.basename(f)), out)
            print(f"   ✅ {os.path.basename(f)} Done")
        except Exception as e:
            print(e)

if __name__ == "__main__":
    main()