# -*- coding: utf-8 -*-
"""
File 3 Loop V2: 3D 交互式循环检验工具 (全标签支持版)
功能：
1. [颜色升级] 支持 V4/V5 版本引入的所有 Level 4 标签 (RB2, RB3, LB6, BasalTrunk等)。
2. [同色系] 子分支颜色与其父肺叶保持色系一致，但有区分。
"""
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.lines import Line2D
import os
import glob

# ================= ⚙️ 配置区域 =================
TARGET_FOLDER = "./output/"
# ==============================================

# --- 基础色 ---
COLOR_TRACHEA = "#D3D3D3"  # 浅灰 (气管)
COLOR_UNKNOWN = "#202020"  # 深黑 (背景骨架)

# --- 全面的颜色字典 (覆盖 Level 1 - Level 4) ---
COLORS = {
    "Trachea": COLOR_TRACHEA,
    "Trachea_Anomaly": "#FFFFFF",     # 亮白 (气管变异)

    # === 右肺 (Right Lung) - 暖色系 (红/橙/黄) ===
    "RightMain": "#FF4500",           # 橙红
    "RightMain_Accessory": "#FF6347", # 番茄红

    # 右上叶 (RUL) 家族 - 橙色系
    "RightUpperLobe": "#FFA500",      # 纯橙
    "RB1": "#FFD700",                 # 金色 (尖段 - 向上)
    "RB2": "#CD853F",                 # 秘鲁色 (后段)
    "RB3": "#FF8C00",                 # 深橙 (前段)
    "RB2+3": "#F4A460",               # 沙褐色 (前后干)
    "RUL_Accessory": "#FFE4B5",       # 鹿皮色 (副支)

    # 中间段 (BI)
    "BronchusIntermedius": "#DAA520", # 金麒麟色

    # 右中叶 (RML) - 洋红/粉色系 (为了区分)
    "RightMiddleLobe": "#FF00FF",     # 亮洋红

    # 右下叶 (RLL) 家族 - 深红/棕色系
    "RightLowerLobe": "#8B0000",      # 深红
    "RB6": "#A52A2A",                 # 棕色 (背段)
    "RightBasalTrunk": "#B22222",     # 耐火砖红 (基底干)

    # === 左肺 (Left Lung) - 冷色系 (蓝/青/紫) ===
    "LeftMain": "#0000FF",            # 纯蓝

    # 左上叶 (LUL) 家族 - 青/蓝系
    "LeftUpperLobe": "#00FFFF",       # 青色
    "LB1+2": "#4169E1",               # 皇家蓝 (尖后段)
    "LB3": "#1E90FF",                 # 道奇蓝 (前段)
    "LeftLingular": "#32CD32",        # 酸橙绿 (舌叶 - 稍微带点绿区分)

    # 左下叶 (LLL) 家族 - 深蓝/紫系
    "LeftLowerLobe": "#00008B",       # 深蓝
    "LB6": "#8A2BE2",                 # 蓝紫 (背段 - 显眼一点)
    "LeftBasalTrunk": "#483D8B",      # 暗板岩蓝 (基底干)
    
    # === 通用标记 ===
    "Spur": "#696969",                # 暗灰 (被算法判定为毛刺/噪点的)
}

def pick_color(anat):
    if not anat: return COLOR_UNKNOWN
    # 模糊匹配：如果标签是 "RightUpperLobe_Sub1" 这种未定义的，
    # 尝试退回到 "RightUpperLobe"
    if anat in COLORS:
        return COLORS[anat]
    
    # 尝试找父级颜色
    if "_Sub" in anat or "_Accessory" in anat:
        base = anat.split("_")[0]
        if base in COLORS: return COLORS[base]
        
    return COLOR_UNKNOWN

def force_full_view(ax, all_points):
    """自动调整 3D 视野范围"""
    if not all_points: return
    points = np.vstack(all_points)
    min_vals = points.min(axis=0)
    max_vals = points.max(axis=0)
    center = (max_vals + min_vals) / 2
    max_range = (max_vals - min_vals).max()
    buffer = max_range * 0.55 
    ax.set_xlim(center[0]-buffer, center[0]+buffer)
    ax.set_ylim(center[1]-buffer, center[1]+buffer)
    ax.set_zlim(center[2]-buffer, center[2]+buffer)
    ax.set_box_aspect((1, 1, 1))
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

def visualize_one_file(filepath, current_idx, total_count):
    filename = os.path.basename(filepath)
    print(f"👉 [{current_idx}/{total_count}] 渲染中: {filename}")
    
    try:
        data = np.load(filepath, allow_pickle=True)
        if isinstance(data, np.ndarray): data = data.tolist()
    except Exception as e:
        print(f"   ❌ 失败: {e}")
        return

    fig = plt.figure(figsize=(16, 12), dpi=120)
    plt.subplots_adjust(left=0.05, right=0.75, top=0.95, bottom=0.05)
    
    ax = fig.add_subplot(111, projection='3d')
    ax.set_facecolor("white")

    all_points = []
    labeled_count = 0
    
    for item in data:
        pts = item.get('member')
        if pts is None or len(pts) < 2: continue
        pts = np.array(pts)
        all_points.append(pts)
        
        anat = item.get('anatomy')
        color = pick_color(anat)
        
        # 样式：有名字的画粗，没名字的画细
        if anat and anat in COLORS:
            lw = 2.0
            alpha = 0.9
            labeled_count += 1
        elif anat == "Spur":
            lw = 0.5 # 毛刺画得很细
            alpha = 0.3
        else:
            lw = 0.8
            alpha = 0.2 # 未知分支画淡一点
            
        ax.plot(pts[:,0], pts[:,1], pts[:,2], c=color, lw=lw, alpha=alpha)

    force_full_view(ax, all_points)
    
    # --- 动态图例 (只显示当前图中存在的标签) ---
    # 为了避免图例太长，我们只列出图中实际用到的颜色
    present_labels = set([item.get('anatomy') for item in data])
    legend_elements = []
    
    # 按照特定解剖顺序排序
    priority_order = [
        "Trachea", 
        "RightMain", "RightUpperLobe", "RB1", "RB2", "RB3", 
        "BronchusIntermedius", "RightMiddleLobe", 
        "RightLowerLobe", "RB6", "RightBasalTrunk",
        "LeftMain", "LeftUpperLobe", "LB1+2", "LeftLingular",
        "LeftLowerLobe", "LB6", "LeftBasalTrunk"
    ]
    
    for key in priority_order:
        if key in present_labels:
            legend_elements.append(Line2D([0], [0], color=COLORS[key], lw=3, label=key))
            present_labels.remove(key) # 移除已添加的
            
    # 添加剩下的（比如 Accessory）
    for key in present_labels:
        if key in COLORS:
             legend_elements.append(Line2D([0], [0], color=COLORS[key], lw=2, label=key))

    ax.legend(handles=legend_elements, 
              loc='center left', 
              bbox_to_anchor=(1.0, 0.5), 
              fontsize='small', 
              frameon=True,
              title=f"Detected Anatomy\n(Total: {labeled_count})")
    
    plt.title(f"File: {filename}\n[Visual V2] Full Level-4 Support", fontsize=14)
    print(f"   ✨ 窗口已弹出...")
    plt.show() 
    plt.close(fig)

def main():
    if not os.path.exists(TARGET_FOLDER): return
    files = glob.glob(os.path.join(TARGET_FOLDER, "*.npy"))
    if not files: return
    files.sort()
    
    print(f"🚀 开始可视化 {len(files)} 个文件...")
    for i, f_path in enumerate(files):
        visualize_one_file(f_path, i+1, len(files))

if __name__ == "__main__":
    main()