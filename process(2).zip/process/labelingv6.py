# -*- coding: utf-8 -*-
"""
File 2 V5: 终极全覆盖版 (N叉树适配 + 向量竞价匹配)
核心改进：
1. [N叉树支持] 彻底放弃 k1,k2 的二元限制，支持任意数量的子分支(三分叉/四分叉)。
2. [向量竞价] 针对 RUL/LLL 等部位，定义期望向量(如向上/向后)，让子分支竞争匹配。
3. [BI重构] 引入"中心线连续性"与"对立面"逻辑，精准识别 RML 与 RB6。
"""
import numpy as np
import os
import glob
from collections import deque

INPUT_DIR = "./npy/"
OUTPUT_DIR = "./output/"

# ================= 🔧 向量工具箱 =================
def normalize(v):
    n = np.linalg.norm(v)
    return v / n if n > 1e-6 else np.array([0,0,1])

def get_angle(v1, v2):
    """计算夹角 (0-180度)"""
    dot = np.dot(normalize(v1), normalize(v2))
    return np.degrees(np.arccos(np.clip(dot, -1.0, 1.0)))

def get_vec(node):
    """获取节点向量 (Start -> End)"""
    p1 = np.array(node['start_point'])
    p2 = np.array(node['end_point'])
    return p2 - p1

# ================= 🧠 核心算法类 =================
class AnatomyNavigator:
    def __init__(self, data):
        self.node_map = {str(d['id']): d for d in data}
        self.results = {} 
        self.subtree_weights = {} 
        self.children_map = {}
        for d in data:
            fid = str(d['father_id'])
            if fid not in self.children_map: self.children_map[fid] = []
            self.children_map[fid].append(str(d['id']))
        self._calc_subtree_weights()

    def _calc_subtree_weights(self):
        for nid in self.node_map:
            if nid not in self.subtree_weights:
                self._get_weight_recursive(nid)

    def _get_weight_recursive(self, nid):
        if nid in self.subtree_weights: return self.subtree_weights[nid]
        node = self.node_map[nid]
        w = node['length']
        for cid in self.children_map.get(nid, []):
            w += self._get_weight_recursive(cid)
        self.subtree_weights[nid] = w
        return w

    def solve(self):
        print("   🧠 启动 N叉树全覆盖标记...")
        root_id = self._find_robust_root()
        if not root_id: return {}
        self._solve_recursive_path(root_id, "Trachea")
        return self.results

    def _find_robust_root(self):
        candidates = []
        for nid, node in self.node_map.items():
            fid = str(node['father_id'])
            if fid == "-1" or fid not in self.node_map:
                z_max = max(node['start_point'][2], node['end_point'][2])
                candidates.append((nid, z_max))
        if not candidates: return None
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][0]

    def _trace_linear_path(self, start_id):
        """穿透追踪：返回路径和【所有】有效孩子"""
        curr_id = start_id
        path_nodes = []
        while True:
            path_nodes.append(curr_id)
            kids_ids = self.children_map.get(curr_id, [])
            kids = [self.node_map[k] for k in kids_ids]
            
            if not kids: return path_nodes, self.node_map[curr_id], []
            
            # 按权重排序
            kids.sort(key=lambda x: self.subtree_weights[str(x['id'])], reverse=True)
            
            # 单行道 -> 穿透
            if len(kids) == 1:
                curr_id = str(kids[0]['id'])
                continue
            
            # 统治度校验 (防止噪点)
            w_big = self.subtree_weights[str(kids[0]['id'])]
            w_second = self.subtree_weights[str(kids[1]['id'])]
            ratio = w_second / w_big if w_big > 0 else 0
            
            # 如果老二太弱，说明是假分叉
            if ratio < 0.15: 
                # 标记其他所有弱小的为 Spur
                for k in kids[1:]: self.results[k['id']] = "Spur"
                # 继续沿老大穿透
                curr_id = str(kids[0]['id'])
                continue
            else:
                # 真分叉：返回所有过了阈值的孩子
                valid_kids = []
                for k in kids:
                    if self.subtree_weights[str(k['id'])] / w_big > 0.10:
                        valid_kids.append(k)
                    else:
                        self.results[k['id']] = "Spur"
                return path_nodes, self.node_map[curr_id], valid_kids

    def _solve_recursive_path(self, start_id, label):
        path_ids, junction_node, children = self._trace_linear_path(start_id)
        for pid in path_ids: self.results[pid] = label
            
        if not children: return

        # === 核心：N叉树匹配逻辑 ===
        
        # 1. Trachea -> RMB / LMB
        if label == "Trachea":
            children.sort(key=lambda k: (k['start_point'][0] + k['end_point'][0])/2)
            if len(children) >= 2:
                rmb = children[0]
                lmb = children[-1]
                self._solve_recursive_path(rmb['id'], "RightMain")
                self._solve_recursive_path(lmb['id'], "LeftMain")
                for k in children[1:-1]:
                    self._solve_recursive_path(k['id'], "Trachea_Anomaly")

        # 2. RightMain -> RUL / BI
        elif label == "RightMain":
            v_parent = get_vec(junction_node)
            angles = [(k, get_angle(get_vec(k), v_parent)) for k in children]
            angles.sort(key=lambda x: x[1], reverse=True) # 夹角大的在前
            
            rul = angles[0][0]
            self._solve_recursive_path(rul['id'], "RightUpperLobe")
            
            rest = [x[0] for x in angles[1:]]
            bi = rest[-1] # 夹角最小的
            self._solve_recursive_path(bi['id'], "BronchusIntermedius")
            
            for k in rest[:-1]:
                self._solve_recursive_path(k['id'], "RightMain_Accessory")

        # 3. LeftMain -> LUL / LLL
        elif label == "LeftMain":
            children.sort(key=lambda k: k['end_point'][2]) # Z 升序
            lll = children[0] # 最下面的
            self._solve_recursive_path(lll['id'], "LeftLowerLobe")
            for k in children[1:]:
                self._solve_recursive_path(k['id'], "LeftUpperLobe")

        # =========================================================
        # 🔥 4. BronchusIntermedius (BI) -> RML / RLL / RB6 重构 🔥
        # =========================================================
        elif label == "BronchusIntermedius":
            v_parent = get_vec(junction_node)
            
            # 准备候选数据: (node, angle, norm_vec)
            candidates = []
            for k in children:
                v_k = get_vec(k)
                norm_v = normalize(v_k)
                ang = get_angle(v_k, v_parent)
                candidates.append({
                    'node': k,
                    'ang': ang,
                    'vec': norm_v,
                    'id': k['id']
                })
            
            # 按夹角升序排序 (最小夹角 = 最好的 Centerline Continuity)
            candidates.sort(key=lambda x: x['ang'])
            
            # [Centerline Continuity]
            # 夹角最小(<30~35度)且向下(Z<0)的，锁定为主路(下叶)
            centerline = candidates[0] 
            
            # [The Opposite] & [Check the Trio]
            remaining = candidates[1:]
            rb6_found_here = False
            
            for item in remaining:
                # 坐标系假设：Y+ 为前(Anterior), Y- 为后(Posterior) (基于 RB2/3 逻辑)
                y_val = item['vec'][1]
                z_val = item['vec'][2]
                ang = item['ang']
                
                # 1. 寻找对立面 - RB6 (背段)
                # 特征：明显向后 (Y < -0.2)
                if y_val < -0.2:
                    self._solve_recursive_path(item['id'], "RB6")
                    rb6_found_here = True
                
                # 2. 寻找对立面 - RML (中叶)
                # 特征：明显向前 (Y > 0.2)
                elif y_val > 0.2:
                     self._solve_recursive_path(item['id'], "RightMiddleLobe")
                
                # 3. 模糊地带判断
                else:
                    # 如果夹角较大(>45) 且 翘起来(Z值不是极低) -> RML
                    if ang > 45:
                        self._solve_recursive_path(item['id'], "RightMiddleLobe")
                    else:
                        # 否则归为下叶附属分支
                        self._solve_recursive_path(item['id'], "RightLowerLobe_Accessory")
            
            # 标记主路
            # 如果在这里检测到了 RB6 (Trio结构)，则主路已经是纯 Basal Trunk
            if rb6_found_here:
                self._solve_recursive_path(centerline['id'], "RightBasalTrunk")
            else:
                # 否则标记为 RLL，让下一级逻辑去拆分 RB6 和 Basal
                self._solve_recursive_path(centerline['id'], "RightLowerLobe")

        # === Level 4: 肺段级 N 叉匹配 ===
        
        # 5. RightUpperLobe
        elif label == "RightUpperLobe":
            pool = children[:]
            pool.sort(key=lambda k: get_vec(k)[2], reverse=True)
            if pool and get_vec(pool[0])[2] > 0:
                rb1 = pool.pop(0)
                self._solve_recursive_path(rb1['id'], "RB1")
            
            if len(pool) >= 2:
                pool.sort(key=lambda k: get_vec(k)[1]) # Y 升序 (后 -> 前)
                rb2 = pool.pop(0)
                rb3 = pool.pop(-1)
                self._solve_recursive_path(rb2['id'], "RB2")
                self._solve_recursive_path(rb3['id'], "RB3")
            elif len(pool) == 1:
                self._solve_recursive_path(pool[0]['id'], "RB2+3")
            
            for k in pool:
                self._solve_recursive_path(k['id'], "RUL_Accessory")

        # 6. LeftUpperLobe
        elif label == "LeftUpperLobe":
            pool = children[:]
            pool.sort(key=lambda k: k['end_point'][2])
            lingula = pool.pop(0)
            self._solve_recursive_path(lingula['id'], "LeftLingular")
            for k in pool:
                if get_vec(k)[2] > 0:
                    self._solve_recursive_path(k['id'], "LB1+2")
                else:
                    self._solve_recursive_path(k['id'], "LB3")

        # 7. LeftLowerLobe
        elif label == "LeftLowerLobe":
            v_parent = get_vec(junction_node)
            angles = [(k, get_angle(get_vec(k), v_parent)) for k in children]
            angles.sort(key=lambda x: x[1], reverse=True)
            lb6 = angles[0][0]
            self._solve_recursive_path(lb6['id'], "LB6")
            for k in [x[0] for x in angles[1:]]:
                self._solve_recursive_path(k['id'], "LeftBasalTrunk")

        # 8. RightLowerLobe (标准二分模式)
        elif label == "RightLowerLobe":
            v_parent = get_vec(junction_node)
            angles = [(k, get_angle(get_vec(k), v_parent)) for k in children]
            angles.sort(key=lambda x: x[1], reverse=True)
            
            # 只有当上一级没有切分 RB6 时，这里才会有 RB6
            # 这里的逻辑是：夹角最大的(岔出去的)是背段
            rb6 = angles[0][0]
            self._solve_recursive_path(rb6['id'], "RB6")
            
            for k in [x[0] for x in angles[1:]]:
                self._solve_recursive_path(k['id'], "RightBasalTrunk")
        
        # 9. 通用 Sub 标记
        else:
            for i, k in enumerate(children):
                sub_label = f"{label}_Sub{i+1}"
                self._solve_recursive_path(k['id'], sub_label)

def main():
    if not os.path.exists(INPUT_DIR): return
    if not os.path.exists(OUTPUT_DIR): os.makedirs(OUTPUT_DIR)
    
    files = glob.glob(os.path.join(INPUT_DIR, "*.npy"))
    print(f"🚀 V5 处理开始 (N叉树全覆盖模式)...")
    
    for f in files:
        try:
            raw = np.load(f, allow_pickle=True)
            data = raw.tolist() if isinstance(raw, np.ndarray) else raw
            nav = AnatomyNavigator(data)
            res = nav.solve()
            
            out = []
            for item in data:
                out.append({
                    "id": item['id'],
                    "member": item.get('member', []),
                    "start_point": item.get('start_point'),
                    "end_point": item.get('end_point'),
                    "anatomy": res.get(str(item['id']), None)
                })
            np.save(os.path.join(OUTPUT_DIR, os.path.basename(f)), out)
            print(f"   ✅ {os.path.basename(f)} Done")
        except Exception as e:
            print(e)

if __name__ == "__main__":
    main()